chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: "https://ru.get-save.com" });
});